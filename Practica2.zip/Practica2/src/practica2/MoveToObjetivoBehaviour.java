/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2;

import jade.core.behaviours.OneShotBehaviour;

/**
 *
 * @author Miguel
 */
public class MoveToObjetivoBehaviour extends OneShotBehaviour{
    Agente ag;
    public MoveToObjetivoBehaviour(Agente a){
        ag = a;
    }
    
    public void action(){
        ag.getEntorno().verificarCasillasAdyacentes(ag.getPosicionActual());
        
        
        if(ag.getPasos().isEmpty() || !ag.getEntorno().isFree(ag.getPasos().get(0).x, ag.getPasos().get(0).y)){
            ag.setPasos(ag.obtenerCaminoHasta(ag.getPosicionObjetivo()));
        }
        
        ag.setPosicionActual(ag.getPasos().get(0));
        ag.getPasos().remove(0);    
    } 
}
